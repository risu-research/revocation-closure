"""Validate an artifact archive or extracted module against a trusted release inventory."""
import argparse,hashlib,json,stat,zipfile
from pathlib import Path,PurePosixPath

def require(ok,message):
    if not ok: raise ValueError(message)
def digest(b):return hashlib.sha256(b).hexdigest()
def file_digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def valid_name(n):
    p=PurePosixPath(n)
    return bool(n) and not p.is_absolute() and p.as_posix()==n and all(x not in ('.','..') for x in p.parts) and '\\' not in n and ':' not in n and '\x00' not in n

def strict_json(b):
    def unique(pairs):
        d={}
        for k,v in pairs:
            require(k not in d,'duplicate JSON key '+k);d[k]=v
        return d
    return json.loads(b,object_pairs_hook=unique,parse_constant=lambda s:(_ for _ in ()).throw(ValueError(s)))

def read_pins(path,expected):
    raw=path.read_bytes();require(digest(raw)==expected,'external inventory digest');return strict_json(raw)

def archive_inventory(path):
    with zipfile.ZipFile(path) as z:
        names=set();folded=set();files={};dirs=set()
        for info in z.infolist():
            n=info.filename.rstrip('/') if info.is_dir() else info.filename
            require(valid_name(n) and n not in names and n.casefold() not in folded,'invalid or repeated archive entry: '+n)
            names.add(n);folded.add(n.casefold());mode=stat.S_IFMT(info.external_attr>>16)
            require(mode in (0,stat.S_IFDIR if info.is_dir() else stat.S_IFREG),'nonregular archive entry: '+n)
            if info.is_dir():dirs.add(n);continue
            files[n]=digest(z.read(info))
        require(files and len({n.split('/')[0] for n in files})==1,'one package root required')
        for n in files:
            require(all(p.as_posix() not in files for p in PurePosixPath(n).parents if p.as_posix()!='.'),'file/directory conflict')
        require(all(any(n.startswith(d+'/') for n in files) for d in dirs),'empty directory entry')
        root=next(iter(files)).split('/')[0]
        return {'root':root,'files':{n[len(root)+1:]:h for n,h in sorted(files.items())}}

def verify_archive(path,pin):
    require(path.is_file() and not path.is_symlink(),'regular archive required')
    require(file_digest(path)==pin['archive_sha256'],'archive digest')
    got=archive_inventory(path);require(got=={'root':pin['root'],'files':pin['files']},'archive inventory');return len(got['files'])

def verify_tree(root,pin):
    require(root.is_dir() and not root.is_symlink(),'regular directory required')
    seen={};dirs=set();expected_dirs={p.as_posix() for n in pin['files'] for p in PurePosixPath(n).parents if p.as_posix()!='.'}
    for p in root.rglob('*'):
        n=p.relative_to(root).as_posix();require(valid_name(n) and not p.is_symlink(),'unsafe tree path: '+n)
        mode=p.lstat().st_mode
        if stat.S_ISDIR(mode):dirs.add(n);continue
        require(stat.S_ISREG(mode) and n in pin['files'],'unexpected file: '+n)
        h=file_digest(p);require(h==pin['files'][n],'file digest: '+n);seen[n]=h
    require(seen==pin['files'] and dirs==expected_dirs,'tree inventory');return len(seen)

def main():
    p=argparse.ArgumentParser();p.add_argument('manifest',type=Path);p.add_argument('manifest_sha256');p.add_argument('module');p.add_argument('target',type=Path);p.add_argument('--tree',action='store_true');a=p.parse_args()
    pin=read_pins(a.manifest,a.manifest_sha256)['modules'][a.module]
    count=verify_tree(a.target,pin) if a.tree else verify_archive(a.target,pin)
    print('PASS',a.module,count,'files')
if __name__=='__main__':main()
