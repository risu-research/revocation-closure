# Manuscript-to-evidence guide

Companion to *After the Clawback: Revocation Closure in Agentic Legal Workflows*.

The original artifact remains at [DOI 10.5281/zenodo.24412056](https://doi.org/10.5281/zenodo.24412056), GitHub commit `43991454d3345a85f36464c6a6011e0b519a723d`. The supplement adds the executable clause assessment, receiver replay, authority history, crash recovery and delivery studies. Each case count describes its own fixed matrix; overlapping conditions and repeated runs are separate comparisons, not independent samples of real matters.

## Original research

Use the [original coverage index](https://github.com/risu-research/revocation-closure/blob/43991454d3345a85f36464c6a6011e0b519a723d/results/PAPER_TO_ARTIFACT_COVERAGE.md) and [original reproduction guide](https://github.com/risu-research/revocation-closure/blob/43991454d3345a85f36464c6a6011e0b519a723d/REPRODUCING.md).

| Paper section | Evidence in original repository |
| --- | --- |
| II.A–C: orders, coding, clauses, deadlines | `experiments/court_coding/`, `experiments/court_policy/`, `experiments/actor_clock/` |
| III–IV: selective repair and checkpoint history | `experiments/court_policy/`, `experiments/component_history/` |
| V.B: 2,160 provenance-fault executions | `experiments/provenance_stress/`, `results/PROVENANCE_STRESS_EVIDENCE.md` |
| V.C: 540 observed-read executions | `experiments/observed_tool_reads/`, `results/OBSERVED_TOOL_READ_EVIDENCE.md` |
| V.D: 180 development and 540 held-out recovery records | `experiments/retrospective_recovery/` |
| VI.A–B: checkpoint-to-effect, 1,152 race experiments | `experiments/component_history/`, `experiments/external_effects/` |
| VI.C–E: custody, program-origin evidence, independent receiver | `experiments/trusted_custody/`, `experiments/program_binding/`, `experiments/independent_recipient/` |
| VI.F–H: clocks, document-to-effect, 17 versus 12 effects | `experiments/actor_clock/`, `experiments/document_to_effect/`, `experiments/policy_integrity/` |

The original repository's own instructions cover its framework and OS-specific execution environments. The supplement runner executes the twelve included modules.

## Supplementary research

After extraction, the paths in the Evidence column are relative to the module's root. See [catalog.json](catalog.json) for archive names and extraction roots.

| Paper section and finding | Module | Evidence |
| --- | --- | --- |
| II.D: 18 historical rules and separate duty assessment | `historical-compiler`, `scoped-policy` | `results/policy_compiler/`, `inputs/contract.json`, `recorded/scoped/verification.json` |
| II.D: Camm copy duty on paraphrases; 243 combinations (54 approvals preserved, 27 holds, 162 unchanged blocks/holds); 6,615 ordinary-use decisions unchanged | `scoped-policy` | `recorded/bridge/integrated_cases.json` (`bridge_paraphrase`), `recorded/bridge/guard_regression.json`; recomputed by the module's `reproduce.py archived` |
| VI.H: two misrouted effects and four unsupported-mode effects; four clean controls preserved | `policy-diagnostics` | `diagnostic_comparison.json`, `physical_effect_ledger.csv`, `results/` |
| VI.H: 92 historical requests, 24 effects | `recipient-replay` | `recorded/full_replay.csv`, `recorded/physical_ledger.csv`, `recorded/verification.json`, `recorded/runs/` |
| VI.I: role and authority facts, signed requests and current histories | `signed-recipient`, `fact-history`, `authority-snapshot` | `inputs/cases.json` and module-specific `recorded/` audits; [evidence guide](EVIDENCE.md) |
| VI.I: 120 timing cases, post-ingress 10/8/8 versus post-authority-commit 10/0/0 | `commit-boundary` | `inputs/commit_cases.json`, `recorded/audit.json`, `recorded/study/` |
| VI.I: 72 process-termination cases; 12/12 pre-commit restriction losses, 0/12 after commit; 56/72 initial response predictions matched | `process-recovery` | `inputs/crash_cases.json`, `inputs/oracle_amendments.json`, `recorded/audit.json`, `recorded/study/` |
| VI.I: receipt-only versus complete-outbox recovery, 8/8 versus 0/8 before receipt commit | `restriction-recovery` | `inputs/recovery_cases.json`, `recorded/audit.json`, `recorded/study/`; separate boundary and hardened regression evidence in `recorded/` |
| VI.I: signed omission and rollback; witnessed omission 0/8, joint rollback 8/8, unwitnessed restriction 8/8 | `witness-recovery` | `inputs/witness_cases.json`, `recorded/audit.json`, `recorded/study/` |
| VI.I: 120 matched delivery cases; 24/32, 16/24, 8/0 post-restriction receipts/processing commits | `external-delivery` | `inputs/delivery_cases.json`, `recorded/study_audit.json`, `recorded/study/` (five primary schedules per role and fixture) |
| VI.I: eight commits following a restriction after final query; 48 retries and eight late body receipts; 24 state-only historical receipts with zero additional bodies | `external-delivery` | `inputs/boundary_cases.json`, `recorded/boundary_audit.json`, `recorded/boundary/`, and retry cases in `recorded/study/` |

## Recount manuscript results

```sh
python -B verify_release.py
python -B verify_paper_results.py
python -B reproduce_all.py archived --out ../archived-check
```

`verify_paper_results.py` independently recounts the physical effect rows and controlled chronology for 664 fixed schedules across five modules; `paper_results.json` records the resulting manuscript metrics. It also checks the Camm paraphrase record and its regression summary. The scoped-policy module recomputes those policy assessments from the executable rules. The module-specific archived auditors validate signatures, case identities, request schedules, trace/SQL linkage and the remaining conditions. This direct recount complements those audits. Timing comes from the controlled harness. The legal source register and each module's fixed policy interpretation define the modeled events.

For a comparison against newly generated evidence:

```sh
python -B reproduce_all.py fresh --out ../fresh-check --workers 2
python -B verify_paper_results.py --fresh-results ../fresh-check/results
```

The two runs should agree case by case on the checked physical effects and timing classifications. Random challenge values and physical pager layout can differ. The Camm generated result files should match byte for byte. All request bodies, identities and service implementations in the supplement are synthetic. The physical ingress counter measures arrival at the synthetic service, separate from a processing commit.
