"""Check pinned reuse relationships against the distributed upstream and downstream bytes."""
import csv,json,zipfile
from reproduce_all import ROOT,catalog,need

def check():
    rows,pins=catalog();byroot={p['root']:p for p in pins.values()};archives={r['root']:r['archive'] for r in rows}
    seen={};expected={}
    for r in rows:
        root=r['root'];pin=byroot[root]
        with zipfile.ZipFile(ROOT/'modules'/archives[root]) as z:
            for n in pin['files']:
                if not n.startswith('inputs/') or not n.endswith('pins.json') or n.count('/')!=1:continue
                j=json.loads(z.read(root+'/'+n))
                if 'files' not in j:continue
                for path,h in j['files'].items():
                    if isinstance(h,str):expected[(root,n,path)]=h
    with (ROOT/'source_lineage.csv').open(newline='') as f:
        for r in csv.DictReader(f):
            key=(r['module'],r['pin_file'],r['local_path']);need(key not in seen,'duplicate lineage row');h=r['sha256'];need(expected.get(key)==h,'source pin mismatch')
            need(byroot[r['module']]['files'][r['local_path']]==h,'local file mismatch')
            need(byroot[r['upstream_module']]['files'][r['upstream_path']]==h,'upstream file mismatch');seen[key]=h
    need(seen==expected,'lineage coverage');print('PASS source reuse links',len(seen));return len(seen)
if __name__=='__main__':check()
