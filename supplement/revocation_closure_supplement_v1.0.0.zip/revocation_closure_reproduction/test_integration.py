"""Distribution and upstream snapshot verifier negative controls."""
import hashlib, json, os, tempfile, unittest
from pathlib import Path
from legacy import snapshot,git_blob
from reproduce_all import catalog,ROOT
from verify_distribution import verify_archive,verify_tree
import zipfile
class Integration(unittest.TestCase):
 def test_catalog_and_archives(self):
  rows,pins=catalog();self.assertEqual(len(rows),12)
  self.assertEqual(sum(r['files'] for r in rows),8459)
  for r in rows:
   p=pins[r['archive']];self.assertEqual(verify_archive(ROOT/'modules'/r['archive'],p),r['files'])
   for n in r['evidence']:self.assertIn(n,p['files'])
   for cmd in r['integrity_commands']:
    for n in cmd[:1]:self.assertIn(n,p['files'])
 def test_snapshot(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);p=root/'a';p.write_bytes(b'hello\n');os.chmod(p,0o644)
   expected=hashlib.sha256(b'100644 ce013625030ba8dba906f756967f9e9ca394464a a\n').hexdigest()
   pin={'tracked_regular_files':1,'tracked_bytes':6,'tree_manifest_sha256':expected}
   self.assertEqual(git_blob(p.read_bytes()),'ce013625030ba8dba906f756967f9e9ca394464a')
   self.assertEqual(snapshot(root,pin)['files'],1)
   p.write_bytes(b'jello\n');self.assertRaises(ValueError,snapshot,root,pin);p.write_bytes(b'hello\n')
   x=root/'extra';x.write_bytes(b'');self.assertRaises(ValueError,snapshot,root,pin);x.unlink()
   x.mkdir();self.assertRaises(ValueError,snapshot,root,pin);x.rmdir()
   os.chmod(p,0o755);self.assertRaises(ValueError,snapshot,root,pin);os.chmod(p,0o644)
   p.unlink();p.symlink_to('/dev/null');self.assertRaises(ValueError,snapshot,root,pin)
 def test_extracted_inventory(self):
  rows,pins=catalog();r=rows[0];p=pins[r['archive']]
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)
   with zipfile.ZipFile(ROOT/'modules'/r['archive']) as z:z.extractall(root)
   base=root/r['root'];self.assertEqual(verify_tree(base,p),r['files'])
   x=base/'__pycache__';x.mkdir();(x/'extra').write_bytes(b'x');self.assertRaises(ValueError,verify_tree,base,p)
if __name__=='__main__':unittest.main(verbosity=2)
