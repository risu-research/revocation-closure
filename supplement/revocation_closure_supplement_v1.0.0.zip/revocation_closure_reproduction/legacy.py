"""Fetch or verify the fixed upstream research repository independently of its later branches."""
import argparse, hashlib, json, os, stat, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PIN=json.loads((ROOT/'legacy_pin.json').read_text())

def need(ok,message):
    if not ok:raise ValueError(message)

def git_blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode('ascii')+b'\0'+data).hexdigest()

def snapshot(root,pin=PIN,allow_git=False):
    need(root.is_dir() and not root.is_symlink(),'snapshot must be a regular directory')
    rows=[];size=0;dirs=set();names=set()
    for p in root.rglob('*'):
        rel=p.relative_to(root);name=rel.as_posix()
        if allow_git and rel.parts[0]=='.git':continue
        need(not p.is_symlink(),'symlink: '+name)
        need(name.isascii() and '\n' not in name and '\r' not in name and '\\' not in name,'unsafe name: '+name)
        if p.is_dir():dirs.add(name);continue
        need(stat.S_ISREG(p.lstat().st_mode),'nonregular path: '+name)
        mode='100755' if p.stat().st_mode & stat.S_IXUSR else '100644'
        b=p.read_bytes();rows.append((name,mode,git_blob(b)));size+=len(b);names.add(name)
    expect_dirs={q.as_posix() for n in names for q in Path(n).parents if q.as_posix()!='.'}
    need(dirs==expect_dirs,'unexpected empty directory')
    manifest=''.join(f'{m} {h} {n}\n' for n,m,h in sorted(rows)).encode('ascii')
    digest=hashlib.sha256(manifest).hexdigest()
    need(len(rows)==pin['tracked_regular_files'],'tracked file count')
    need(size==pin['tracked_bytes'],'tracked byte count')
    need(digest==pin['tree_manifest_sha256'],'upstream content fingerprint')
    return {'files':len(rows),'bytes':size,'tree_manifest_sha256':digest}

def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()

def checkout(root):
    need((root/'.git').is_dir() and not (root/'.git').is_symlink(),'ordinary Git checkout required')
    need(git(root,'rev-parse','HEAD')==PIN['commit'],'wrong commit')
    need(not git(root,'status','--porcelain','--untracked-files=all','--ignored'),'checkout must be pristine')
    return snapshot(root,allow_git=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['fetch','checkout','snapshot']);p.add_argument('path',type=Path);a=p.parse_args();root=a.path.absolute()
    if a.mode=='fetch':
        need(not root.exists() and not root.is_symlink(),'new destination required')
        subprocess.run(['git','clone','--no-checkout',PIN['repository']+'.git',str(root)],check=True)
        subprocess.run(['git','-C',str(root),'checkout','--detach',PIN['commit']],check=True)
    result=snapshot(root) if a.mode=='snapshot' else checkout(root)
    print(json.dumps({'status':'PASS','commit':PIN['commit'],**result},sort_keys=True))
if __name__=='__main__':main()
