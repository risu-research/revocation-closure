"""Check the release directory inventory and its nested experiment archives."""
import hashlib, stat
from pathlib import Path, PurePosixPath
from reproduce_all import ROOT,catalog,need
from verify_distribution import verify_archive
from verify_lineage import check as check_lineage

def check():
    need(__debug__,'assertions must be enabled')
    expected={}
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        h,n=line.split('  ',1);p=PurePosixPath(n)
        need(n not in expected and n==p.as_posix() and not p.is_absolute() and '..' not in p.parts and '\\' not in n and len(h)==64 and all(c in '0123456789abcdef' for c in h),'invalid manifest row')
        expected[n]=h
    actual={};dirs=set()
    for p in ROOT.rglob('*'):
        n=p.relative_to(ROOT).as_posix();need(not p.is_symlink(),'symlink: '+n)
        if p.is_dir():dirs.add(n);continue
        need(stat.S_ISREG(p.lstat().st_mode),'nonregular file: '+n)
        if n!='SHA256SUMS':actual[n]=hashlib.sha256(p.read_bytes()).hexdigest()
    need(actual==expected,'release inventory or digest mismatch')
    need(dirs=={d.as_posix() for n in expected for d in PurePosixPath(n).parents if d.as_posix()!='.'},'directory inventory mismatch')
    rows,pins=catalog();n=sum(verify_archive(ROOT/'modules'/r['archive'],pins[r['archive']]) for r in rows)
    check_lineage();print('PASS release files',len(actual),'modules',len(rows),'module files',n)
if __name__=='__main__':check()
