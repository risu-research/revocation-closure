# Revocation Closure — supplementary research reproduction collection

Version 1.0.0

Companion research materials for *After the Clawback: Revocation Closure in Agentic Legal Workflows*.

The collection connects selected historical legal rules, agent source dependencies, current permissions, durable recipient effects, recovery and external delivery. It preserves the earlier published repository at its fixed commit and supplies twelve self-contained supplementary experiment modules. Their original inputs, implementation lineage, recorded evidence, and independent auditors remain separate; the collection never combines overlapping fixture counts into a single sample.

## Quick start

Use Linux, Python 3.12 or later, local SQLite and loopback HTTP. Process-termination experiments send signals to synthetic worker processes that they create. Run in a disposable local environment with assertions enabled. The supplement uses the standard library and the pinned cryptography package. No commercial AI service, credentials, real client records or paid API are required. A package installation may require internet access; after dependencies are present, these twelve modules execute offline.

```sh
python -m venv ../revocation-venv
. ../revocation-venv/bin/activate
python -m pip install -r requirements.txt
python -B verify_release.py
python -B reproduce_all.py verify
python -B verify_lineage.py
python -B test_integration.py
python -B verify_paper_results.py
python -B reproduce_all.py archived --out ../archived-check
python -B reproduce_all.py integrity --out ../integrity-check
python -B reproduce_all.py fresh --out ../fresh-check --workers 2
```

The last command performs actual HTTP, SQLite and process-termination experiments in separate new output directories. It may require several minutes or longer depending on the host. Each command rejects an existing output directory. `all` runs archived, applicable integrity tests, and fresh checks together. `--select` accepts the module IDs in [catalog.json](catalog.json), allowing separately logged subsets with distinct new directories. The `report.json` in each workspace records selection, interpreter versions, execution status, and log paths. A selected subset cannot be interpreted as a full-collection run. Each module's source directory is verified before and after execution. Module-level comparison rules preserve random challenge values and pager-dependent physical layout as run-specific details; fixed inputs, semantic judgments, durable effects and applicable chronology are the reproduction targets.

For example, to reproduce the primary external delivery comparison and its separate boundary controls:

```sh
python -B reproduce_all.py fresh --select external-delivery --out ../external-check --workers 2
```

## Original publication artifact

The original [v1.1.0 release](https://github.com/risu-research/revocation-closure/releases/tag/v1.1.0) remains the basis for court-order coding, checkpoint and provenance experiments, trusted source custody, original component tests, retrospective recovery, and the earlier document-to-effect studies. The supplementary modules build on its selected source records and experiments. This collection includes the original source identity and a checkout verifier, with the original source repository fetched separately:

```sh
python -B legacy.py fetch ../revocation-original
```

If a pristine checkout is already available, use `python -B legacy.py checkout ../revocation-original`. For an extracted source snapshot without Git metadata, use `python -B legacy.py snapshot ../revocation-original`. These commands require the precise 254-file, 1,653,441-byte content identity in [legacy_pin.json](legacy_pin.json). The checkout command also verifies the fixed Git commit. The source snapshot can be retained locally for offline inspection. The original [reproduction guide at the pinned commit](https://github.com/risu-research/revocation-closure/blob/43991454d3345a85f36464c6a6011e0b519a723d/REPRODUCING.md) contains the original commands and separate dependencies, including LangGraph, PostgreSQL, Docker, and Linux isolation requirements for selected experiments. Run those commands in their supported environment. The supplement's runner covers its twelve included modules; the upstream full workflow is a separate reproduction gate. The original [version DOI](https://doi.org/10.5281/zenodo.24412056) identifies v1.1.0. Its Zenodo deposit records an open software archive of 783,141 bytes with MD5 `217bdc4cced7be323b24b10615172f8d`. After downloading and extracting that original archive, use the snapshot verifier to check the full Git content fingerprint. The [concept DOI](https://doi.org/10.5281/zenodo.24410798) identifies the original repository's archived version series.

## Evidence navigation

- [Manuscript-to-evidence guide](PAPER_TO_ARTIFACT.md) links paper sections and exact results to the original repository and included modules. `verify_paper_results.py` directly recounts 664 fixed schedules and checks the Camm regression records.
- [Evidence guide](EVIDENCE.md) maps research questions to modules, records, and interpretation limits.
- [Module catalog](catalog.json) lists exact archive filenames, module roots, primary evidence, and integrity commands. After extraction, paths are relative to each module root.
- [Legal source register](legal_sources.csv) identifies the seven selected entered orders and two federal rules, with the historical page locators. The linked court documents retain their own terms.
- [Source reuse ledger](source_lineage.csv) records 229 file-level reuse relationships; `verify_lineage.py` checks each current parent and child against the fixed distribution. [Historical archive pins](historical_archive_pins.json) retain the original source archive identities. Audit and runner updates change archive hashes without changing reused research source bytes. The earlier archive hashes describe provenance and need not equal the updated archive hashes.
- [Legacy source links](legacy_source_links.json) give 15 direct Git blob links to the original fixed commit. The original repository retains the rest of its source and evidence index.
- [Distribution inventory](candidate_set.json) pins all twelve archives and every extracted file. Obtain the distribution's outer SHA-256 through its trusted release record. An internal hash manifest alone establishes consistency within the supplied package; independent identity depends on the trusted release digest.

The [citation file](CITATION.cff) identifies the supplement and its original version-specific dependency. The supplement is a separate research software deposit. Its own version-specific DOI is assigned by the archive upon publication.

The MIT license covers the research code. Policy interpretations and generated facts, accounts, request payloads, signing keys and receiving services are synthetic research fixtures. The selected court orders and third-party software retain their own terms. Cite the paper and applicable archived software version separately.
