"""Verify, extract and independently run the fixed research modules in a new workspace."""
import argparse, hashlib, importlib.metadata, json, os, platform, sqlite3, subprocess, sys, time, zipfile
from pathlib import Path
from verify_distribution import read_pins, verify_archive, verify_tree
ROOT=Path(__file__).resolve().parent
INVENTORY_SHA256='8b7ddf9d2380cf236a2104170b43352bae3576ea2e576ee44a5941dcee2ff713'
HEAVY={'recipient_policy_replay','crash_recovery','durable_notice','external_delivery','witness_recovery'}

def need(ok,msg):
    if not ok:raise ValueError(msg)

def catalog():
    pins=read_pins(ROOT/'candidate_set.json',INVENTORY_SHA256)['modules']
    rows=json.loads((ROOT/'catalog.json').read_text())['modules']
    need(len(rows)==len(pins)==12,'module inventory count')
    need({r['archive'] for r in rows}==set(pins) and len({r['id'] for r in rows})==12,'catalog coverage')
    need(all(r['root']==pins[r['archive']]['root'] for r in rows),'root mismatch')
    return rows,pins

def environment():
    env={k:v for k,v in os.environ.items() if not k.startswith('PYTHON')}
    env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0',PYTHONHASHSEED='0')
    return env

def main():
    need(__debug__,'assertions must be enabled')
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['verify','archived','fresh','integrity','all']);p.add_argument('--out',type=Path);p.add_argument('--select',nargs='+');p.add_argument('--workers',type=int,default=2);p.add_argument('--timeout',type=int,default=1800);a=p.parse_args();need(a.workers>0 and a.timeout>0,'positive worker count and timeout')
    rows,pins=catalog();known={r['id'] for r in rows};selected=set(a.select or known);need(selected<=known and selected,'unknown module selection')
    rows=[r for r in rows if r['id'] in selected]
    need({x.name for x in (ROOT/'modules').iterdir()}==set(pins),'archive directory inventory')
    for r in rows:
        pin=pins[r['archive']];n=verify_archive(ROOT/'modules'/r['archive'],pin);print('Verified',r['id'],n,'files',flush=True)
    if a.mode=='verify':return
    need(a.out is not None,'output required');out=a.out.resolve();need(not out.exists() and out!=ROOT and ROOT not in out.parents,'new workspace outside distribution required');out.mkdir(parents=True)
    (out/'modules').mkdir();(out/'results').mkdir();(out/'logs').mkdir()
    env=environment();records=[]
    try:crypto=importlib.metadata.version('cryptography')
    except importlib.metadata.PackageNotFoundError:crypto=None
    report={'mode':a.mode,'selected':sorted(selected),'all_modules_selected':selected==known,'python':platform.python_version(),'sqlite':sqlite3.sqlite_version,'cryptography':crypto,'platform':platform.system(),'inventory_sha256':INVENTORY_SHA256,'runs':records}
    def save():
        report['complete']=len(records)==len(rows)
        report['passed']=report['complete'] and all(r['status']=='PASS' for r in records)
        (out/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    save()
    for r in rows:
        pin=pins[r['archive']];base=out/'modules'/r['root'];entry={'id':r['id'],'root':r['root'],'runs':[],'status':'FAIL'};t=time.monotonic()
        try:
            with zipfile.ZipFile(ROOT/'modules'/r['archive']) as z:z.extractall(out/'modules')
            verify_tree(base,pin)
            modes=['archived','integrity','fresh'] if a.mode=='all' else [a.mode]
            for mode in modes:
                if mode=='integrity':
                    scripts=r['integrity_commands'];cmds=[[sys.executable,'-B',*s] for s in scripts]
                    if not scripts:entry['runs'].append({'mode':mode,'status':'NOT_APPLICABLE'});continue
                else:
                    cmd=[sys.executable,'-B','reproduce.py',mode]
                    if mode=='fresh':
                        cmd+=['--out',str(out/'results'/r['root'])]
                        if r['root'] in HEAVY:cmd+=['--workers',str(a.workers)]
                    cmds=[cmd]
                for i,cmd in enumerate(cmds):
                    log=out/'logs'/f'{r["id"]}.{mode}.{i}.log'
                    with log.open('w') as f:
                        # Use a separate process group so a timeout cannot leave experiment workers running.
                        proc=subprocess.Popen(cmd,cwd=base,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
                        try:rc=proc.wait(timeout=a.timeout)
                        except subprocess.TimeoutExpired:
                            import signal
                            try:os.killpg(proc.pid,signal.SIGKILL)
                            except ProcessLookupError:pass
                            proc.wait();rc=124
                    entry['runs'].append({'mode':mode,'command':cmd[2:],'exit':rc,'log':log.relative_to(out).as_posix()});need(rc==0,mode+' exit '+str(rc))
                verify_tree(base,pin)
            entry['status']='PASS'
        except Exception as e:entry['error']=str(e)
        entry['seconds']=round(time.monotonic()-t,2);records.append(entry);save();print(r['id'],entry['status'],flush=True)
    need(report['passed'],'one or more selected modules failed; see report.json')
if __name__=='__main__':main()
