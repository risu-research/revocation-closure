"""Recount selected manuscript results from fixed cases and physical evidence.
The module-specific auditors separately verify signatures, exact requests and provenance.
Timing uses the controlled harness event order, not an independent clock.
"""
import argparse, collections, json, pathlib, sqlite3, tempfile, zipfile
from reproduce_all import ROOT, catalog
from verify_distribution import verify_archive, verify_tree
P=pathlib.Path

def need(ok,msg):
    if not ok: raise ValueError(msg)
def read(p):return json.loads(p.read_text())
def sql(p,q):
    need(p.is_file(),f'missing DB {p.name}')
    with sqlite3.connect(p.resolve().as_uri()+'?mode=ro',uri=True) as db:
        return db.execute(q).fetchall()
def events(t,k):return [x for x in t if x['kind']==k]
def ordered(t):need([x['order'] for x in t]==list(range(1,len(t)+1)),'trace order')
def key(c,cols):return '-'.join(c[k] for k in cols)
def load_cases(p):return read(p)
def external(root,c):
    t=read(root/'trace.json');ordered(t)
    ingress=sql(root/'external.sqlite','select id,delivery_id,payload_sha256 from ingress order by id')
    eff=sql(root/'external.sqlite','select ingress_id,delivery_id,payload_sha256 from effects order by ingress_id')
    ins=events(t,'payload_ingress');com=events(t,'external_commit');cut=events(t,'restriction_committed');cut=cut[0]['order'] if cut else float('inf')
    need(ingress==[(x['id'],x['delivery_id'],x['digest']) for x in ins],'ingress link')
    need(len(eff)==len(com),'effect count');need(all((i,d,h) in ingress for i,d,h in eff),'effect provenance')
    need([x['delivery_id'] for x in com]==[x[1] for x in eff],'commit delivery ID')
    need(sql(root/'queue.sqlite','select count(*) from effects')==[(1,)],'queue row')
    vals={'ingress':len(ingress),'effects':len(eff),'late_ingress':sum(x['order']>cut for x in ins),'late_commit':sum(x['order']>cut for x in com)}
    need(all(vals[k]==c[k] for k in vals),'external frozen values')
    if c['schedule']=='after_provider_check':need(next(x['order'] for x in events(t,'gate') if x['stage']=='provider_commit')<cut<com[0]['order'],'final check race')
    if c['schedule']=='before_send' and c['mode']=='preflight_commit':
        need(next(x['order'] for x in events(t,'gate') if x['stage']=='provider_preflight')<cut<ins[0]['order'],'preflight race')
        need(not next(x['allowed'] for x in events(t,'gate') if x['stage']=='provider_commit'),'provider final refusal')
    if c['schedule']=='lost_response_status_only_revoked':
        need(len(events(t,'response_discarded'))==1 and len(ins)==len(com)==1 and com[0]['order']<cut,'status-only historical effect')
        need(any(x['valid'] for x in events(t,'status_verified')),'status verified')
        need(not [x for x in ins if x['order']>cut],'no late ingress')
    return vals

def commit(root,c):
    t=read(root/'trace.json');ordered(t);mode=c['mode'];shared=mode=='shared'
    recipient=root/('authority.sqlite' if shared else 'recipient.sqlite')
    effects=sql(recipient,'select attempt_id from effects order by attempt_id')
    marks=[x for x in events(t,'recipient_committed') if x['response']['verdict']=='ALLOW']
    need([x['response']['attempt_id'] for x in marks]==[x[0] for x in effects],'commit marker ID')
    ingress=events(t,'restriction_ingress');ack=[x for x in t if x.get('endpoint')=='/head' and x.get('side')=='authority' and x['packet']['head']['body']['sequence']==2]
    need(len(ack)==len(ingress),'restriction ack count')
    for x in ack:
        aid=x['response']['attempt_id'];need(sql(root/'authority.sqlite',f'select count(*) from heads where attempt_id={int(aid)}')==[(1,)],'durable restriction')
    probes=events(t,'writer_probe');after_i=after_c=0
    for x in marks:
        if c['schedule']=='reauthorized' or not ingress:continue
        after_i+=ingress[0]['order']<x['order']
        if shared:after_c+=ack[0]['response']['attempt_id']<x['response']['attempt_id']
        elif mode=='reservation' and probes:
            need(x['order']<events(t,'reservation_released')[0]['order'],'reservation order')
        else:after_c+=ack[0]['order']<x['order']
    vals={'effects':len(effects),'post_ingress':after_i,'post_authority_commit':after_c,'contended':sum(x['busy'] for x in probes)}
    need(all(vals[k]==c[k] for k in vals),'commit frozen values')
    return vals

def crash(root,c):
    t=read(root/'trace.json');ordered(t);k=events(t,'killed');need(len(k)==1 and k[0]['returncode']==-9,'actual termination record')
    p=root/('authority.sqlite' if c['mode']=='shared' else 'recipient.sqlite')
    n=sql(p,'select count(*) from effects')[0][0];need(n==c['effects'],'crash physical effect oracle')
    if c['name'] in ('head_pre','head_post'):
        need(events(t,'crash_request')[0]['endpoint']=='/head','restriction crash request')
        need(k[0]['counts']['authority']['heads']==(4 if c['name']=='head_pre' else 5),'restriction durability at termination')
        need(sql(root/'authority.sqlite','select count(*) from heads where sequence=2')==[(1,)],'restriction eventually durable')
        need(n==(1 if c['name']=='head_pre' else 0),'restriction loss effect')
        if n:
            a=[x for x in t if x.get('endpoint')=='/submit' and x.get('response',{}).get('verdict')=='ALLOW'];h=[x for x in t if x.get('endpoint')=='/head' and x.get('response',{}).get('verdict')=='HEAD_ACCEPTED' and x.get('generation')==2]
            need(len(a)==len(h)==1 and k[0]['order']<a[0]['order']<h[0]['order'],'write before restriction retry')
    observed=[];pending_collect=False
    for x in t:
        if x['kind']=='crash_request':pending_collect=x['collect']
        elif x['kind']=='killed' and pending_collect:observed.append(x['response']['verdict'])
        elif x['kind']=='http' and x.get('collect'):observed.append(x['response']['verdict'])
    return {'effects':n,'initial_response_match':int(observed==c['expected']),'kills':len(k)}


def count(root, c):
    n = sql(root/'recipient.sqlite', 'select count(*) from effects')[0][0]
    need(n == c['effects'], 'fixed effect count')
    return {'effects': n}

SPECS = [
    ('external_delivery','delivery_cases.json','study',('base','role','mode','schedule'),external),
    ('external_delivery','boundary_cases.json','boundary',('base','role','mode','schedule'),external),
    ('commit_boundary','commit_cases.json','study',('base','mode','role','schedule'),commit),
    ('crash_recovery','crash_cases.json','study',('base','mode','role','name'),crash),
    ('witness_recovery','witness_cases.json','study',('base','role','condition'),count),
    ('durable_notice','recovery_cases.json','study',('base','role','mode','phase'),count),
]

def collect(modules, fresh=None):
    results={}
    for mod, fixture, part, cols, fn in SPECS:
        mroot=modules/mod
        if fresh is None:
            rroot=mroot/'recorded'/part
        else:
            rroot=fresh/mod
            if mod in ('external_delivery','durable_notice'):rroot=rroot/part
        cases=read(mroot/'inputs'/fixture)
        ids={key(c,cols) for c in cases}
        need(len(ids)==len(cases) and {p.name for p in rroot.iterdir() if p.is_dir()}==ids,'case coverage '+mod+'/'+part)
        for c in cases:
            k=key(c,cols)
            results[mod,part,k]={'module':mod,'matrix':part,**{x:c[x] for x in cols},**fn(rroot/k,c)}
    return results

def summarize(records, modules):
    rows=list(records.values())
    def agg(mod, fields, **filter):
        s=[r for r in rows if r['module']==mod and all(r.get(k)==v for k,v in filter.items())]
        return {'cases':len(s),**{k:sum(r[k] for r in s) for k in fields}}
    summary={'case_schedules':len(rows),'commit_boundary':{},'process_recovery':{},'restriction_recovery':{},'witness_recovery':{},'delivery_primary':{},'delivery_boundary':{},'delivery_retry':{}}
    for mode in ('snapshot','reservation','shared'):
        summary['commit_boundary'][mode]=agg('commit_boundary',('effects','post_ingress','post_authority_commit','contended'),mode=mode)
    for name in ('head_pre','head_post'):
        summary['process_recovery'][name]=agg('crash_recovery',('effects','kills'),name=name)
    summary['process_recovery']['initial']=agg('crash_recovery',('effects','initial_response_match','kills'))
    for mode in ('receipt','reconcile'):
        summary['restriction_recovery'][mode]=agg('durable_notice',('effects',),mode=mode,phase='before_receipt')
    for cond in ('clean','sender_only_omission','witnessed_omission','witness_rollback_pinned','joint_rollback','unwitnessed_omission'):
        summary['witness_recovery'][cond]=agg('witness_recovery',('effects',),condition=cond)
    summary['witness_recovery']['all']=agg('witness_recovery',('effects',))
    schedules=('clean','before_dispatch','after_dispatch_check','before_send','after_ingress')
    for mode in ('queue_only','dispatch_gate','preflight_commit'):
        s=[r for r in rows if r['module']=='external_delivery' and r['matrix']=='study' and r['mode']==mode and r['schedule'] in schedules]
        summary['delivery_primary'][mode]={'cases':len(s),**{k:sum(r[k] for r in s) for k in ('ingress','effects','late_ingress','late_commit')}}
        summary['delivery_primary'][mode]['unrestricted_effects']=sum(r['effects'] for r in s if r['schedule']=='clean')
    for schedule in ('after_provider_check','lost_response_status_only_revoked'):
        summary['delivery_boundary'][schedule]=agg('external_delivery',('ingress','effects','late_ingress','late_commit'),matrix='boundary',schedule=schedule)
    s=[r for r in rows if r['module']=='external_delivery' and r['matrix']=='study' and 'lost_response' in r['schedule']]
    summary['delivery_retry']={'cases':len(s),**{k:sum(r[k] for r in s) for k in ('ingress','effects','late_ingress','late_commit')}}
    bridge=modules/'scoped_legal_policy'/'recorded'/'bridge'
    summary['camm_regression']=read(bridge/'guard_regression.json')
    para=next(x for x in read(bridge/'integrated_cases.json') if x['id']=='bridge_paraphrase')
    need(para['result']['verdict']=='BLOCK' and para['result']['deadlines'][0]['amount']==5 and para['result']['deadlines'][0]['unit']=='business_days' and para['request']['facts']['reproduces_confidential_text'] is False,'Camm copy duty')
    summary['camm_paraphrase']={'verdict':'BLOCK','deadline_business_days':5}
    return summary

def main():
    need(__debug__,'assertions required')
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--fresh-results',type=P,help='results directory of a complete fresh reproduction');ap.add_argument('--out',type=P,help='new report file outside release directory');a=ap.parse_args()
    rows,pins=catalog()
    with tempfile.TemporaryDirectory() as t:
        modules=P(t)
        for r in rows:
            if r['root'] not in {x[0] for x in SPECS}|{'scoped_legal_policy'}:continue
            zpath=ROOT/'modules'/r['archive'];pin=pins[r['archive']];verify_archive(zpath,pin)
            with zipfile.ZipFile(zpath) as z:z.extractall(modules)
            verify_tree(modules/r['root'],pin)
        archived=collect(modules);summary=summarize(archived,modules)
        expected=read(ROOT/'paper_results.json');need(summary==expected,'manuscript result recount mismatch')
        result={'archived':summary,'fresh_comparison':'not requested'}
        if a.fresh_results:
            fresh=collect(modules,a.fresh_results)
            need(fresh==archived,'fresh case-level comparison mismatch')
            for name in ('guard_regression.json','integrated_cases.json'):
                p=P('scoped_legal_policy')/'bridge'/name
                need((a.fresh_results/p).read_bytes()==(modules/'scoped_legal_policy'/'recorded'/'bridge'/name).read_bytes(),'fresh scoped result mismatch: '+name)
            result['fresh_comparison']={'status':'PASS','case_schedules':len(fresh),'camm_files':2}
        if a.out:
            out=a.out.resolve();need(ROOT not in out.parents and out!=ROOT,'report must be outside release directory')
            with out.open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
        print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
